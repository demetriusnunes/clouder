=begin

RNotify.rb

Copyright (LGPL) 2006 Luca Russo
vargolo@gmail.com

=end

require 'gtk2'
require 'rnotify.so'

module Notify
  BINDINGS_VERSION = "0.3.3"
end
